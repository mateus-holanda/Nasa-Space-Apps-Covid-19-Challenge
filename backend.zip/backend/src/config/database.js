const mongoose = require("mongoose")
mongoose.Promise = global.Promise
module.exports = mongoose.connect("mongodb://localhost/covid", { useNewUrlParser: true, useUnifiedTopology: true });

mongoose.Error.messages.general.required = "The field '{PATH}' is required.";
mongoose.Error.messages.Number.min = 
    "The '{VALUE}' informed is less than the min limit of '{MIN}'.";
mongoose.Error.messages.Number.max = 
    "The '{VALUE}' informed is bigger than the max limit of '{MAX}'.";
mongoose.Error.messages.String.enum = 
    "'{VALUE}' is not valid for the field '{PATH}'.";