import React, { Component } from "react";
import { Map, TileLayer } from "react-leaflet";
import HeatmapLayer from "../../heatmap/src/HeatmapLayer";
import Basemap from "./Basemap";
import { addressPoints } from "./data";
import "./Map.css";

class DeviceMap extends Component {

  constructor() {
    super();
    this.onBMChange = this.onBMChange.bind(this);
    this.coronavirus = this.coronavirus.bind(this);
    this.state = {
      lat: -15.09005,
      lng: -51.28964,
      zoom: 4,
      minZoom: 2,
      maxZoom: 17,
      basemap: "satellite"
    };
  };

  onBMChange(bm) {
    this.setState({
      basemap: bm
    });
  };

  coronavirus() {

    // Data format used:
    //x0 - Population
    //x1 - Instant Temperature (correlação negativa)
    //x2 - Umidade relativa (correlação negativa)
    //x3 - Poluição do ar
    //x4 - Casos confirmados diarios

    //De acordo com o artigo
    // x0 - Exposure
    // x1,x2,x3,x4 - Hazard and Vulnerability

    //x_i é o vetor dos dados lidos pelas APIs no formato:
    //x_i=[x0 x1 x2 x3 x4]

    // Value limits are as below
    const x_0_min = 0, x_0_max=212000000, x_1_min=-4, x_1_max=43.9, x_2_min=0,
          x_2_max=100, x_3_min=0, x_3_max=10, x_4_min=0, x_4_max=100000;
  }

  render() {
    const position = [this.state.lat, this.state.lng];
    const basemapsDict = {
      streets: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
      terrain: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
      dark: "https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png",
      satellite: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    };
    
    return (
      <Map center={position} zoom={this.state.zoom} minZoom={this.state.minZoom} maxZoom={this.state.maxZoom}>
          
          <TileLayer
              attribution="Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community"
              url={basemapsDict[this.state.basemap]}
          />
          <Basemap basemap={this.state.basemap} onChange={this.onBMChange} />
          {/* <HeatmapLayer
            fitBoundsOnLoad
            fitBoundsOnUpdate
            points={addressPoints}
            longitudeExtractor={m => m[1]}
            latitudeExtractor={m => m[0]}
            intensityExtractor={m => parseFloat(m[2])} /> */}
        </Map>
    );
  }
}

export default DeviceMap;