import React, { Component } from "react";

class Basemap extends Component {

  constructor() {
    super();
    this.onChange = this.onChange.bind(this);
  }

  onChange(e) {
    var basemap = e.currentTarget.value;

    if (this.props.onChange) {
      this.props.onChange(basemap);
    }
  }

  render() {
    return (
      <div className="basemaps-container">
        <select value={this.props.basemap} onChange={this.onChange}>
          <option value="satellite">Satellite</option>
          <option value="streets">Streets</option>
          <option value="terrain">Terrain</option>
          <option value="dark">Dark</option>
        </select>
      </div>
    );
  }
};

export default Basemap;