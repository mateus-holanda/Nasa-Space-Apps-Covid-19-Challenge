import React from "react"
import Navbar from "./navbar"
import Icon from '../../../public/images/logo_manifest.png'
import Logo from "../../../public/images/logotipo-neofield-1.svg"

export default props => (
    <header className="main-header">
        <a href="/#/" className="logo">
            <span className="logo-mini">
                <img src={Icon} alt="Ícone" height="30" />
            </span>
            <span className="logo-lg">
            <img src={Logo} alt="Neofield Logo" width="150" />
            </span>        
        </a>
        <nav className="navbar navbar-static-top">
            <a href className="sidebar-toggle" data-toggle="offcanvas"></a>
            <Navbar />
        </nav>
    </header>
)