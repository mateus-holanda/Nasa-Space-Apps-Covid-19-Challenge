import React from "react"

export default props => (
    <footer className="main-footer"> 
        <strong> 
            &copy;2020 E²MoC Todos os direitos reservados.
        </strong>
    </footer>
)