import React from "react"
import MenuItem from "./menuItem"

export default props => (
	<ul className="sidebar-menu">
		<MenuItem path="/" label="Dashboard" icon="pie-chart" />
		<MenuItem path="maps" label="Mapas" icon="globe" />
		<MenuItem path="probeFactoriesList" label="Estações" icon="list-alt" />
		<MenuItem path="probeFactoriesTests" label="Testes" icon="flask" />
		<MenuItem path="probeFactoriesQuality" label="Controle de Qualidade" icon="bar-chart-o" />
		<MenuItem path="probeInstallation" label="Instalação de Estações" icon="qrcode" />

	</ul>
)