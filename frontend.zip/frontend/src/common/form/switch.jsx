import React from "react"
import Grid from "../layout/grid"

export default props => (
    <Grid cols={props.cols}>
        <div className="pretty p-switch p-fill">
            <label htmlFor={props.name}>{props.label}</label>
            <input {...props.input}
                className="pretty-checkbox"
                placeholder={props.placeholder}
                readOnly={props.readOnly}
                type="checkbox"
            />
        </div>
    </Grid>
)


// import React from "react";
// import Grid from "../layout/grid"

// const Switch = ({ isOn, handleToggle, onColor }) => {
//   return (
//     <Grid cols={props.cols}>
//       <div className="pretty p-switch p-fill">
//       	<input
//         	checked={isOn}
//         	onChange={handleToggle}
//         	className="react-switch-label"
// 					id={`react-switch-new`}
// 					placeholder={props.placeholder}
// 					readOnly={props.readOnly}
//         	type="checkbox"
//       	/>
//       <label
//         style={{ background: isOn && onColor }}
//         className="react-switch-label"
//         htmlFor={`react-switch-new`}
// 			>
//       	<span className={`react-switch-button`} />
//       </label>
//       </div>
//     </Grid>
//   );
// };

// export default Switch;