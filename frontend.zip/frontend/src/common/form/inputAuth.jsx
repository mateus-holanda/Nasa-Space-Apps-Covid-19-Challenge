import React from "react"
import If from "../operator/if"

export default props => (
    <If test={!props.hide}>
        <div className={`input-div ${props.classType}`}>
            <div className="i">
                <i className={`fas fa-${props.icon}`}></i>
            </div>
            <div>
                <h5>{props.label}</h5>
                <input {...props.input}
                    className="input"
                    type={props.type} />
            </div>
        </div>
    </If>
)