// import "../common/template/dependencies"
import React from 'react'
import { Switch, Route, Redirect } from 'react-router'

import Dashboard from '../dashboard/dashboard'
import About from '../about/About'

export default props => (
    <div className="content-wrapper">
        <Switch>
            <Route exact path="/" component={Dashboard} />
            <Route path="/about" component={About} />
            <Redirect from="*" to="/" />
        </Switch>
    </div>
)