import React, { Component, useState } from "react";
import { HashRouter } from "react-router-dom";
import Map from "../common/map/Map";
import Monitor from "../images/monitor_wide_screen.svg";

// CSS Files
import "./style.css"

class App extends Component {
  state = { show: true }

  showModal = () => {
    this.setState({ show: true });
  }
  
  hideModal = () => {
    this.setState({ show: false });
  }

  render () {
    const showHideClassName = this.state.show ? 'modal display-block' : 'modal display-none';
    return (
      <HashRouter>
        <div className={showHideClassName}>
          <section className='modal-main'>
            <div className="location-modal">Enter your location</div>
            <input className="input-modal" type="text" label="Location" placeholder="Location"/>
            <button className="button-modal"
              onClick={this.hideModal}
            >
              Enter
            </button>
          </section>
        </div>
        <div className="monitor-img">
          <img src={Monitor} width="850" alt="monitor"/>
          <Map />
        </div>
      </HashRouter>
    )
  }

}

export default App;
