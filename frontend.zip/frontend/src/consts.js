export default {
  API_URL: "http://localhost:3003/api",
  OAPI_URL: "http://localhost:3003/oapi",
}