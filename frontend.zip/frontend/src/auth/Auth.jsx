import React, { Component } from "react";
import { reduxForm, Field } from "redux-form";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import Messages from "../common/msg/messages";
import Input from "../common/form/inputAuth";

// JS files
import "./AuthLogin";
import { login, signup } from "./authActions";

// CSS files
import "./auth.css";

// Logos and Images
import Logo from "../images/logo.png";
import RocketImg from "../images/world.svg";
import WaveImg from "../images/wave.svg";
import Avatar from "../images/avatar.svg";

class Auth extends Component {
    constructor(props) {
        super(props);
        this.state = { loginMode: true };
    };

    changeMode() {
        this.setState({ loginMode: !this.state.loginMode });
    };

    onSubmit(values) {
        const { login, signup } = this.props;
        this.state.loginMode ? login(values) : signup(values);
    };

    render() {
        const { loginMode } = this.state;
        const { handleSubmit } = this.props;
        return (
            <div className="auth-login">
                <div className="container">
                    <img className="wave" src={WaveImg} alt="wave-img"/>
                    <div className="img">
                        <img src={RocketImg} alt="phone-img" />
                    </div>
                    <div className="auth-logo">
                        <img src={Logo} alt="e2moc-logo" width="100"/>
                    </div>
                    <div className="login-container">
                        <form className="auth-form" onSubmit={handleSubmit(v => this.onSubmit(v))}>
                            <h2 className="auth-heading">Covid-Free Maps</h2>
                            <img className="avatar" src={Avatar} alt="avatar-img"/>
                            <Field component={Input} name="name" classType="zero" 
                                icon="user" label="Name" type="input" hide={loginMode} />
                            <Field component={Input} name="email" classType="one"
                                icon="user" label="Email" type="email"/>
                            <Field component={Input} name="password" classType="two"
                                icon="lock" label="Password" type="password"/>
                            <Field component={Input} name="confirm_password" classType="three" 
                                icon="lock" label="Confirm password" type="password" hide={loginMode} />
                            <div className="options">
                                <div className="forgot-pwd">
                                    <a onClick={() => this.changeMode()}>
                                        {loginMode ? "New user? Please, sign up here." :
                                            "Already have an account? Sign in here."}
                                    </a>
                                </div>
                                <div className="forgot-pwd">Forgot password?</div>
                            </div>
                            <button className="btn auth-btn" type="submit">
                                {loginMode ? "Sign In!" : "Sign Up!"}
                            </button>
                        </form>
                    </div>
                </div>
                <Messages />
            </div>
        )
    };
};

Auth = reduxForm({ form: "authForm" })(Auth);
const mapDispatchToProps = dispatch => bindActionCreators({ login, signup }, dispatch);
export default connect(null, mapDispatchToProps)(Auth);
